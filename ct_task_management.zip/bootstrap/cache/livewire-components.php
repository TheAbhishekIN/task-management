<?php return array (
  'task' => 'App\\Http\\Livewire\\Task',
  'task-index' => 'App\\Http\\Livewire\\TaskIndex',
);