<div>
    <div class="p-4 w-full bg-white rounded-lg border border-gray-200 shadow-md sm:p-6 md:p-8">
        <?php if($type == 'delete'): ?>
             <h5 class="text-xl font-medium text-gray-900">Are you sure you want to delete this task?</h5>
             <button wire:click.prevent="deleteTask" class="w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">Delete Task</button>
        <?php else: ?>
    <form class="space-y-6" wire:submit.prevent="saveTask">
        <h5 class="text-xl font-medium text-gray-900">Add Task</h5>
        <div>
            <label for="task" class="block mb-2 text-sm font-medium text-gray-900 ">Task Name</label>
            <input type="text" wire:model="task_name" id="task" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
            <?php $__errorArgs = ['task_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="email" class="block mb-2 text-sm font-medium text-gray-900 ">Select Project</label>
            <select wire:model="project_name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                <option value="">Select Project</option>
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($project->name); ?>" <?php if($project_name == $project->name): ?> selected <?php endif; ?>><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>

        <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save Task</button>
    </form>
            <?php endif; ?>
</div>
</div>
<?php /**PATH E:\laragon\www\ct-task-management\resources\views/livewire/task.blade.php ENDPATH**/ ?>